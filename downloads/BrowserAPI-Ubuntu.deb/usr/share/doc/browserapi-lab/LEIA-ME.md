# BrowserAPI no Ubuntu — sem terminal

Interface experimental para configuração e teste de chats. **Não é um serviço de API pronto.**

## Instalar e abrir

Você informou **Linux Lite 7.2**. Essa distribuição usa a base Ubuntu 24.04,
portanto é um alvo esperado para este pacote, mas não foi instalada uma sessão
Linux Lite completa para homologação. O teste automatizado usa Ubuntu 24.04.
Fonte da base: https://www.linuxliteos.com/forums/showthread.php?tid=9251


- Destinado inicialmente ao **Ubuntu 24.04 ou mais recente, com Python 3.11+**. Ubuntu 22.04 padrão não atende ao requisito; não atualize o Python do sistema para contornar isso.
- Baixe o arquivo **BrowserAPI-Ubuntu.deb** entregue junto com esta orientação.
- Abra o arquivo com o **instalador de pacotes** do Ubuntu e escolha **Instalar**. O Ubuntu pode pedir a senha de administrador na janela do próprio sistema. Nunca envie essa senha no chat.
- Procure **BrowserAPI** no menu de aplicativos e abra.
- Algumas instalações do Ubuntu não têm um programa gráfico que abra arquivos `.deb`. Nesse caso, informe sua versão do Ubuntu e o que aparece ao abrir o arquivo; não é necessário tentar comandos. A instalação gráfica varia entre versões e não foi homologada em um desktop Ubuntu do usuário.

O pacote não instala nada durante a montagem e não contém scripts de instalação privilegiados. O gerenciador de pacotes resolve as dependências declaradas e pede a autorização local necessária. O programa deve rodar como usuário normal, nunca como administrador.

## Atualizar uma instalação existente

Baixe o novo `.deb` e abra no instalador de pacotes, escolhendo atualizar/instalar.
Depois salve seus trabalhos e reinicie o computador, para encerrar a versão antiga
que pode continuar na memória mesmo depois de fechar a aba do painel. Abra
BrowserAPI novamente pelo menu. Não é necessário apagar seus perfis/configurações.

### Se o Google recusar o login

O Chrome controlado por automação pode ser recusado pelo Google, inclusive quando
é o Chrome oficial instalado. O usuário reportou essa recusa no uso real desta
versão inicial. Não peça repetidamente o login nem avance ao apontamento nesse
estado. A atualização identifica a mensagem conhecida (português/inglês na página
de contas Google) e interrompe o fluxo com explicação, mas **não libera o login**.
Não desative proteções da conta, não copie cookies e não compartilhe credenciais.
Não se garante uso do Gemini por este mecanismo.

### Se Enviar só aparecer depois de digitar

A verificação agora preenche o campo somente após autorização e, então, espera
até três segundos por um botão Enviar único, visível e habilitado. Só então tenta
clicar uma vez e exige evidência de uma nova mensagem sua. Se o botão continuar
indisponível/ambíguo, não clica nem reenvia; pode restar um rascunho. Confira a página
antes de autorizar qualquer outra tentativa. Essa correção cobre uma falha interna
reproduzida na fixture, não comprova que explica todo detalhe do site real reportado.

## Na janela do programa

1. Na primeira vez, clique em **Preparar BrowserAPI** e confirme o download. Isso cria um ambiente privado do usuário e baixa Playwright/Chromium. Requer internet e pelo menos 1,5 GB disponíveis. Não instala Chrome nem Edge.
2. Escolha o **navegador** e o **chat**. Dê um nome para salvar; use nomes diferentes para navegadores/chats diferentes.
3. Clique em **Abrir e configurar**. Na outra janela, faça login e escolha o modelo. No modo separado, seu perfil pessoal não é usado e é normal precisar entrar novamente. No modo Chrome já aberto, a conexão é autorizada e reutiliza a sessão existente.
4. Volte ao painel e clique em **Continuar**. Responda aos botões e, se solicitado, aponte os campos na janela do chat. Não é preciso escrever seletores ou código. Esc cancela o apontamento atual.
5. Autorize **uma mensagem de teste**, somente se estiver de acordo. O resultado aparece no painel, com uma orientação caso não funcione.

Depois, use **Testar agora** para uma nova verificação ou **Corrigir campos** se a interface mudar. Para escrever uma mensagem, selecione o chat salvo e use **Conversar**; haverá outra confirmação antes do envio. As respostas são texto na própria janela; não são interpretadas como HTML.

**Interromper operação** cancela a espera por confirmação, seleção e observação. Downloads são encerrados. Operações internas do navegador já iniciadas podem levar até o timeout para voltar. Interromper **não desfaz uma mensagem já enviada**. Não há reenvio automático.

## Se não funcionar

- **Chrome/Edge não abre:** confirme se esse produto está instalado. Ou prepare e escolha **Chromium do BrowserAPI**, salvando com outro nome.
- **Não encontra o campo ou a resposta:** clique em **Corrigir campos** e aponte os controles corretos na janela do chat.
- **Login, CAPTCHA ou limite do site:** resolva manualmente ou aguarde. Não há contorno automático.
- **Já existe um perfil aberto:** feche a outra execução do projeto que usa aquele chat.
- **O teste não confirma envio/resposta:** confira a conversa antes de autorizar outra tentativa, para não duplicar uma mensagem.
- **Download falhou:** verifique a conexão e o espaço disponível; use Preparar novamente. O painel não mostra exceções que possam conter dados privados.

## Privacidade e limites

O painel escuta somente em `127.0.0.1`, com chave aleatória por execução e proteção de origem. Não é acessível pela rede e não oferece API OpenAI. A janela de controle abre no navegador padrão; o navegador selecionado no formulário é o que abre o chat automatizado.

Configurações, recibos e perfis exclusivos ficam em `~/.config/browserapi-lab/`. O ambiente de execução fica em `~/.local/share/browserapi-lab/` (ou em `$XDG_DATA_HOME/browserapi-lab/`). Esses diretórios podem conter sua sessão de login: não os compartilhe. O recibo não inclui mensagens, cookies ou credenciais. Mensagens/respostas exibidas no painel ficam temporariamente na memória até outra operação ou o processo encerrar.

Fechar a aba do painel não encerra o processo local: abrir BrowserAPI de novo no menu reabre o mesmo painel, sem duplicar o perfil. Sair da sessão Ubuntu encerra os processos. A remoção do pacote pelo gerenciador gráfico não apaga seus dados pessoais automaticamente.

O teste sintético não equivale a homologar Gemini/LMArena autenticados, todos os navegadores, todas as versões do Ubuntu ou comparar com uma API real. Sites externos podem mudar. Nenhuma instalação foi feita no computador do usuário nesta sessão.

## O que foi verificado nesta entrega

- Código validado: `7020ea3`; [Actions 40153757793](https://github.com/Financia-Brasil/browserapi-lab/actions/runs/40153757793), aprovado.
- Ubuntu 24.04 em CI: **244 testes, 127,108 s, sem falhas, 1 ignorado** (cenário de ausência de navegador, pois havia navegador instalado).
- Formulário real no painel, segundo Chromium visível sob Xvfb, autorização por botões, configuração e nova verificação com recibo de sucesso na fixture. Cancelamento antes da autorização, negativa, proteção contra HTML executável e orientação de reparo também exercitados.
- Instalador montado, extraído e importado fora do checkout; dependências resolvidas em **simulação**, sem instalar o pacote no sistema.
- Evidência sanitizada: `results/ci/40153757793/gui-flow.json`.
- Preparação com downloads na máquina do usuário, instalação gráfica via gerenciador do Linux Lite e sessão autenticada Gemini/LMArena **não foram executadas** aqui. Não se afirma homologação completa desse desktop.

As primeiras execuções encontraram uma falha no preparo da página sintética do teste: uma substituição de HTML também alterava a string interna do iframe. A fixture foi corrigida, sem relaxar a validação de URLs ou a exigência de autorização. A execução final acima passou.


## Correção após relato de uso real — versão 0.1.0+ubuntu2

O usuário reportou recusa do login Google no navegador controlado e falha de
reconhecimento de Enviar mesmo após apontamento. O bloqueio do Google continua
sem solução garantida: o programa apenas reconhece o aviso conhecido e impede
continuar a configuração nesse estado. Nenhum mecanismo de autenticação ou
proteção foi contornado.

Foi corrigido um defeito reproduzível: exigir Enviar visível antes de preencher.
Agora, após autorização, preenche e só ativa um botão único, visível e habilitado,
com espera limitada. Se falhar, não ativa nem reenvia e informa possível rascunho.
Isso não demonstra que essa era a única causa do erro no Gemini do usuário.

Validação: [Actions 40156336579](https://github.com/Financia-Brasil/browserapi-lab/actions/runs/40156336579),
**SUCCESS, 248 testes em 120,867 s, 1 ignorado**, código `9a59cf6`. Inclui botão
oculto/ausente até digitar, ambiguidade sem envio, rascunho preservado e recusa
Google em página sintética UTF-8 antes do apontamento. O código de execução do
instalador publicado é idêntico ao desse commit; mudanças seguintes só adicionam
documentação, evidências e teste de aviso em inglês (não incluído nessa bateria
completa). Montagem/extração do pacote e simulação de dependências aprovadas.
Não houve novo login autenticado no Google nem execução no computador do usuário.


## Versão 0.1.0+ubuntu3 — microfone/Enviar e Chrome já logado

### Apontar o estado correto do botão

Alguns chats exibem microfone enquanto o campo está vazio e Enviar quando há
texto. Ao usar **Corrigir campos**, o painel pode pedir autorização para escrever
um rascunho temporário **sem enviar**. Aceitando, aponte o botão no estado
**Enviar**. O rascunho do programa é removido apenas se continuar idêntico; se
você alterar o texto, sua edição é preservada. Um rascunho que já existia não é
substituído. Esc cancela o apontamento. Enter fica bloqueado durante a seleção.
O programa recusa controles explicitamente identificados como microfone/voz,
tanto no apontamento quanto antes do clique de envio. Isso não é reconhecimento
universal de qualquer ícone ou de toda mudança possível do site.

### Usar seu Chrome pessoal já aberto e logado — experimental

Esta opção atende ao pedido explícito do usuário de usar o perfil cotidiano,
sem copiar cookies e sem lançar outra instância sobre seu diretório de perfil.

1. Use Chrome **144 ou mais recente**, já aberto no perfil/conta desejados.
2. No Chrome, abra **chrome://inspect/#remote-debugging** e habilite a opção de
   depuração remota. Se a opção não existir, não tente flags/comandos para forçar.
3. Deixe somente uma aba do chat escolhido aberta nesse navegador, na conta e
   no modelo desejados. Outras abas não serão fechadas pelo programa.
4. No formulário BrowserAPI, escolha **Meu Chrome já aberto e logado**, deixe
   Google Chrome selecionado e salve com **outro nome**, por exemplo `gemini-logado`.
5. Leia o aviso de acesso e autorize a conexão no painel e no pedido do próprio
   Chrome. Só aceite se confiar no programa. A autorização de conexão é distinta
   da autorização para enviar uma mensagem.

**Acesso sensível:** a permissão CDP pode acessar todas as abas e contas desse
navegador, não apenas Gemini. O código do BrowserAPI opera apenas a aba do chat
selecionado; isso não é uma barreira de isolamento imposta pelo Chrome. Não
autorize uma conexão de programa desconhecido. Desative a depuração remota na
mesma tela quando não quiser mais permitir solicitações.

O programa conecta ao processo existente e desconecta sem fechar o Chrome, suas
abas ou sua sessão. Se houver mais de uma aba do chat, ele pede para deixar
somente uma em vez de escolher arbitrariamente. Não lê/exporta cookies. A
conexão usa somente o endpoint local publicado pelo próprio Chrome do usuário.
Algumas versões/instalações não disponibilizam esse endpoint; nesse caso falha
com orientação, sem tentar outras portas nem contornar a permissão.

Referência oficial do fluxo de consentimento do Chrome 144+: https://developer.chrome.com/blog/chrome-devtools-mcp-debug-your-browser-session
O projeto usa Playwright diretamente para CDP; não instala MCP/Node nem extensões.
A conexão nativa com permissão no Chrome pessoal e o login real no Google ainda
precisam de validação nesse desktop. Testar CDP em navegador controlado não prova
que o login funcionará nem que toda versão do Chrome disponibiliza esse modo.


### Evidência da versão ubuntu3

[Actions 40157983637](https://github.com/Financia-Brasil/browserapi-lab/actions/runs/40157983637), código `8b11752`: **SUCCESS, 257 testes em 124,149 s, 1 ignorado**.

Exercitados com navegador real e fixture: controle que muda de microfone para
Enviar, recusa de clique em microfone, apontamento real que rejeita voz, rascunho
temporário (consentido/negado/cancelado), preservação de rascunho anterior e de
edições, conexão CDP a um processo já aberto, reconexão sem recarregar a página,
não fechamento do processo/abas e recusa de múltiplas abas do mesmo chat.
O navegador CDP desse teste é um Chromium temporário controlado, não um perfil
pessoal real. O diálogo nativo de permissão do Chrome pessoal, disponibilização
do endpoint em cada versão e a sessão Google do usuário **não foram homologados**.
Também passaram testes de autorização negada antes de conectar, validação de
endpoint local/UID/symlink e montagem/extração do `.deb` com simulação de
dependências Ubuntu 24.04. O pacote publicado contém o mesmo código de execução
do commit validado; mudanças posteriores desta publicação são documentação e
artefato de instalação.
