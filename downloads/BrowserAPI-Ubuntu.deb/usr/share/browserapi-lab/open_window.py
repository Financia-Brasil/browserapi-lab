from browserapi_lab.bootstrap import main
raise SystemExit(main())
