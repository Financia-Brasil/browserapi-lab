from browserapi_lab.gui import main
raise SystemExit(main())
