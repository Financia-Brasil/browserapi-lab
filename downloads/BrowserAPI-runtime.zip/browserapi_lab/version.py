"""Versão do runtime do painel/instalador (distinta da biblioteca de laboratório)."""
APP_VERSION = '0.9.0'
